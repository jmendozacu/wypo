<?php

class MST_Pdp_Block_Adminhtml_Importcategories extends Mage_Adminhtml_Block_Widget_Grid_Container
{
	
}