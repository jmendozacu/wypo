<!--
	Magebay.com
-->
{{#data}}
	<img class="pdp_ins_results" width="150" src="{{images.standard_resolution.url}}" data-full="{{images.standard_resolution.url}}" data-thumb="{{images.thumbnail.url}}"/>
{{/data}}
<input type="hidden" id="pdc_ins_next_url" value="{{pagination.next_url}}" />

